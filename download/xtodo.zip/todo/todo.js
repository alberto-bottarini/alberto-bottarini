var todo = {
	
	//INIT function
	init : function(event) {
		todo.dom.init();
		todo.ajax.init();
		todo.service.loadMenu();
		todo.service.getHomepage(event);
	},
	
	//URL constants
	url : {
		countAllObject: "server/countAllObjects",
		getAllProjects : "server/getAllProjects",
		getAllTasks : "server/getAllTasks",
		getProject : "server/getProject",
		changeTaskStatus: "server/changeTaskStatus",
		removeTask: "server/removeTask",
		removeProject: "server/removeProject",
		newTask: "server/newTask",
		newProject: "server/newProject"
	}
	
};
