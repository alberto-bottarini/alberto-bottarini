
<link rel="stylesheet" href="style.css" TYPE="text/css">
<link rel="stylesheet" href="extension/style.php" TYPE="text/css">
<script src="js/rounder.js"></script>
<script src="js/net.js"></script>
<script src="js/xfile2.js"></script>

<div id="window">

	<div id="titlebar">XFile 2.0</div>
	<div id="linkbar">
		<ul>
			<li id="backlink"></li>
			<li id="aheadlink"></li>
			<li id="uplink"></li>
		</ul>
	</div>
	<div id="content">
		<ul id="listfile"></ul>
	</div>
	<div id="statusbar"></div>

</div>
