<?php
session_start();
if(!isset($_SESSION['xcalendar_user']) || !isset($_POST['id'])) exit();
$userId = $_SESSION['xcalendar_user'];
include("dbconf.php");
include("database.class.php");
$eventId = $_POST['id'];

$db = new database();

$query = "SELECT * FROM events WHERE id = $eventId";
$result = $db->doQuery($query);
if(count($result) == 0) die("Evento non esistente");
$event = $result[0];
if($event['user'] != $userId) die("Non sei il proprietario dell'evento");

$title = mysql_real_escape_string($_POST['title']);
$text = isset($_POST['text']) ? mysql_real_escape_string($_POST['text']) : "";
$type = $_POST['type'];

$query = "UPDATE events SET title = '$title', text='$text', type = $type WHERE id = $eventId";
$db->doQuery($query);
?>
