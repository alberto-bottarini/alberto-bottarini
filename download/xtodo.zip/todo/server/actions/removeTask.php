<?php
if(!isset($_POST['id'])) {
	$error = "No task defined";
} else {
	$query = "SELECT * FROM tasks WHERE id = '".mysql_real_escape_string($_POST['id'])."'";
	$result = mysql_query($query) or die(mysql_error());
	$count = mysql_num_rows($result);
	if($count == 0) $error = "No task with id ".$_POST['id'];
	elseif($count > 1) $error = "More than one task with id ".$_POST['id'];
	else {
		$task = mysql_fetch_assoc($result);
		$query = "SELECT * FROM tasks WHERE project_id = '".$task['project_id']."'";
		$result = mysql_query($query) or die(mysql_error());
		$count = mysql_num_rows($result);
		if($count < 2) $error = "Cannot remove last project task";
		else {
			$query = "DELETE FROM tasks WHERE id = '".$task['id']."'";
			mysql_query($query) or die(mysql_error());			
		}
	}
}
?>

<?php if(!isset($error)) : ?>
	<task>
		<?php foreach($task as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>	
	</task>
<?php endif; ?>
