<?php
if(!isset($_POST['id'])) {
	$error = "No project defined";
} else {
	$query = "SELECT * FROM projects WHERE id = '".mysql_real_escape_string($_POST['id'])."'";
	$result = mysql_query($query) or die(mysql_error());
	$count = mysql_num_rows($result);
	if($count == 0) $error = "No project with id ".$_POST['id'];
	elseif($count > 1) $error = "More than one project with id ".$_POST['id'];
	else {
		$project = mysql_fetch_assoc($result);
		$query = "SELECT * FROM tasks WHERE project_id = '".$project['id']."' ORDER BY enddate ASC, priority DESC, startdate ASC";
		$result = mysql_query($query) or die(mysql_error());
		$tasks = array();
		while($row = mysql_fetch_assoc($result)) $tasks[] = $row;
	}
}
?>

<?php if(!isset($error)) : ?>
	<project>
		<?php foreach($project as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>
		<?php foreach($tasks as $t) : ?>
			<task>
				<?php foreach($t as $key => $value) : ?>
					<?php if(!is_null($value)) : ?>
						<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
					<?php endif; ?>
				<?php endforeach; ?>
			</task>
		<?php endforeach; ?>	
	</project>
<?php endif; ?>
