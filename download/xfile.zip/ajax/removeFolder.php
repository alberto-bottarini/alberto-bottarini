<?php
$folder = $_POST['folder'];
rmdir("../$folder");

?>