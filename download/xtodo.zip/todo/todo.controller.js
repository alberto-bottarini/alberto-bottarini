todo.controller = {
	getHomepage : function() {
		todo.dom.selectTab($('ul#tabs li.general'));
		todo.service.getHomepage();
	},
	getProjectDetails : function(event) {
		var id = event.data;
		var target = event.target;
		todo.dom.selectTab(target);
		todo.service.getProjectDetails(id);
	},
	changeTaskStatus : function(event) {
		var status = event.data.status;
		var id = event.data.id;	
		todo.service.changeTaskStatus(id, status);		
	},
	removeTask : function(event) {
		if(window.confirm("Are you sure??")) {
			var id = event.data;
			todo.service.removeTask(id);
		}
	},
	removeProject : function(event) {
		if(window.confirm("Are you sure??")) {
			var id = event.data;
			todo.service.removeProject(id);
		}
	},	
	taskFormSubmit : function(event) {
		var project_id = event.data;
		var name = $.trim($("input[name='task_name']").val());
		var note = $.trim($("textarea[name='task_note']").val());
		var user = $.trim($("input[name='task_user']").val());
		var priority = $("select[name='task_priority']").val();
		if(name.length == 0 || note.length == 0 || user.length == 0) {
			alert("Task invalid!");
		} else {	
			todo.service.taskFormSubmit(project_id, name, note, user, priority);
			todo.dom.taskFormClose();
		}
		return false;
	},
	projectFormSubmit : function() {
		var name = $.trim($("input[name='project_name']").val());
		var note = $.trim($("textarea[name='project_note']").val());
		if(name.length == 0 || note.length == 0) {
			alert("Project invalid!");
		} else {	
			todo.service.projectFormSubmit(name, note);
			todo.dom.projectFormClose();
		}
		return false;		
	}
}
