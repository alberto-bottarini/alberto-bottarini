/*
---------------------
  GLOBAL VARIABLES
---------------------
*/
var userId;
var lastMex;
var userList = new Array();
var timeout;

/*
---------------------
  GLOBAL FUNCTION
---------------------
*/

window.onload = function() {
  document.getElementById("nickButton").onclick = login;
}

function chat() {
	refresh();
	timeout = setTimeout("chat()",3000);
}

function keyListener(e) {
	if(!e) e=window.event;
	if(e.keyCode==13) sendMex();
}

function mexFocus() {
	document.getElementById("mexInput").value = "";
	document.getElementById("mexInput").focus();
}

function inArray(ar,value) {
	presente = false;
	for(a in ar) if(ar[a] == value) presente = true;
	return presente;
}

/*
---------------------
  LOGIN FUNCTIONS
---------------------
*/
function login() {
	document.getElementById("nickButton").disabled = true;
	var nick = document.getElementById("nickInput").value;
	if(nick = validateNick(nick)) {
		var param = "action=login&nick="+nick;
		new net.ContentLoader("request.php", loginCallback, param);
	}
}

function loginCallback(txt) {
	response = eval('(' + txt + ')');
	userId = response.sessionId;
	var mexText = document.createElement("SPAN");
	mexText.innerHTML = "Messaggio: ";
	var mexInput = document.createElement("INPUT");
	mexInput.setAttribute("id","mexInput");
	mexInput.setAttribute("type","text");
	mexInput.onkeyup = keyListener;
	var mexButton = document.createElement("BUTTON");
	mexButton.onclick = sendMex;
	mexButton.innerHTML = "Invia messaggio";
	var div = document.getElementById("form");
	div.removeChild(document.getElementById("nickInput"));
	div.removeChild(document.getElementById("nickButton"));
	div.removeChild(document.getElementById("nickname"));
	div.appendChild(mexText);
	div.appendChild(mexInput);
	div.appendChild(mexButton);
	var divOnline = document.createElement("DIV");
	divOnline.setAttribute("id","online");
	divOnline.innerHTML = "<b>Utenti online: </b>";
	document.body.appendChild(divOnline);
	var divMex = document.createElement("DIV");
	divMex.setAttribute("id","mex");
	document.body.appendChild(divMex);
	refreshCallback(txt);
	chat();
	mexFocus();	
}

function validateNick(nick) {
	nick = trim(nick);
	if(nick.length==0) alert("Completa il campo nick!");
	else if(nick.length>20) alert("Nick troppo lungo!");
	else return nick;
	document.getElementById("nickButton").disabled = false;
	return false;	
}
/*
---------------------
  SENDMEX FUNCTIONS
---------------------
*/
function sendMex() {
  var mex = document.getElementById("mexInput").value;
	disableMexInput();
	clearTimeout(timeout);
  if(mex = validateMex(mex)) {		
   	var param = "action=sendMex&userId="+userId+"&mex="+mex+"&lastMex="+lastMex;
   	new net.ContentLoader("request.php", sendMexCallback, param);
  }
}

function sendMexCallback(txt) {
	refreshCallback(txt);
	mexFocus();
	timeout = setTimeout("chat()",3000);
	activateMexInput();
}

function disableMexInput() {
	document.getElementById("mexInput").disable = true;
}

function activateMexInput() {
	document.getElementById("mexInput").disable = false;
}

function validateMex(mex) {
	mex = trim(mex);
	if(mex.length==0) {
		activateMexInput();
		timeout = setTimeout("chat()",3000);
		return false;
	} else return mex;
}

function updateMexList(messaggi) {	
	for(i=0; i<messaggi.length;i++) {
			document.getElementById("mex").innerHTML+="<b>"+messaggi[i].data+" "+messaggi[i].utente+":</b>"+messaggi[i].messaggio+"<br/>";
	}
	var dv = document.getElementById("mex");
	dv.scrollTop = dv.offsetHeight;
}
/*
---------------------
  REFRESH FUNCTIONS
---------------------
*/
function refresh() {
	param = "action=refresh&userId="+userId+"&lastMex="+lastMex;
	new net.ContentLoader("request.php", refreshCallback, param);
}

function refreshCallback(txt) {
	var response = eval('(' + txt + ')');	
	updateNickList(response.utenti);
	updateMexList(response.messaggi);
	lastMex = response.lastId;	
}	

function updateNickList(utenti) {
	for(i in utenti) {
		nuovo = utenti[i];
		if(!inArray(userList,nuovo)) addUserOnline(nuovo);
	}
	for(i in userList) {
		vecchio = userList[i];
		if(!inArray(utenti,vecchio)) removeUserOnline(vecchio);
	}
	printUserOnline(utenti);
	userList = utenti;
}

function addUserOnline(username) {
	document.getElementById("mex").innerHTML+="<span class='newUser'><b>E' entrato l'utente "+username+"</span><br/>";
}

function removeUserOnline(username) {
	document.getElementById("mex").innerHTML+="<span class='newUser'><b>L'utente "+username+" ci ha lasciato</span><br/>";
}

function printUserOnline(utenti) {
	document.getElementById("online").innerHTML = "<b>Utenti online:</b> ";
	for(u in utenti) document.getElementById("online").innerHTML+=utenti[u]+" ";	
}