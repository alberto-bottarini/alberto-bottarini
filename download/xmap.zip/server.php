<?php

include("lib/json.php");

if(isset($_POST['current'])) {
	$current = $_POST['current'];
	$current = substr(strrchr($current,"/"),1,strpos(strrchr($current,"/"),".")-1);
	list($w,$h) = explode("_",$current);
}

function getName($w,$h) {
  	global $filename;
  	if(is_file(sprintf($filename,$w,$h))) return sprintf($filename,$w,$h);
  	else return "no.jpg";
}

function checkCentral($w,$h) {
  global $filename;
  return is_file(sprintf($filename,$w,$h));
}

$filename = "map_images/%d_%d.jpg";

$direction = isset($_POST['direction']) ? $_POST['direction'] : "default";

$images = array();

switch($direction) {
  
  case "n":
  	if(checkCentral($w,$h-1)) {
	  	$images[] = getName($w-1,$h-2);
	  	$images[] = getName($w,$h-2);
	  	$images[] = getName($w+1,$h-2);
	  	
	  	$images[] = getName($w-1,$h-1);
	  	$images[] = getName($w,$h-1);
	  	$images[] = getName($w+1,$h-1);
	  	
	  	$images[] = getName($w-1,$h);
	  	$images[] = getName($w,$h);
	  	$images[] = getName($w+1,$h);  			  
		}

  	break;
  	
  case "e":
  	if(checkCentral($w+1,$h)) {
	  	$images[] = getName($w,$h-1);
	  	$images[] = getName($w+1,$h-1);
	  	$images[] = getName($w+2,$h-1); 
	
	  	$images[] = getName($w,$h);
	  	$images[] = getName($w+1,$h);
	  	$images[] = getName($w+2,$h); 
			
		 	$images[] = getName($w,$h+1);
	  	$images[] = getName($w+1,$h+1);
	  	$images[] = getName($w+2,$h+1); 
	  }
  	break;
  	
  case "w":
  	if(checkCentral($w-1,$h)) {
  	  
	  	$images[] = getName($w-2,$h-1);
	  	$images[] = getName($w-1,$h-1);
	  	$images[] = getName($w,$h-1); 
	
	  	$images[] = getName($w-2,$h);
	  	$images[] = getName($w-1,$h);
	  	$images[] = getName($w,$h); 
			
		 	$images[] = getName($w-2,$h+1);
	  	$images[] = getName($w-1,$h+1);
	  	$images[] = getName($w,$h+1); 
  	}
		break;
  	
  case "s":
  	if(checkCentral($w,$h+1)) {
	  	$images[] = getName($w-1,$h);
	  	$images[] = getName($w,$h);
	  	$images[] = getName($w+1,$h); 
	
	  	$images[] = getName($w-1,$h+1);
	  	$images[] = getName($w,$h+1);
	  	$images[] = getName($w+1,$h+1); 
			
	  	$images[] = getName($w-1,$h+2);
	  	$images[] = getName($w,$h+2);
	  	$images[] = getName($w+1,$h+2); 
		}
   	
  	break;
  	
  case "nw":
  	if(checkCentral($w-1,$h-1)) {
	  	$images[] = getName($w-2,$h-2);
	  	$images[] = getName($w-1,$h-2);
	  	$images[] = getName($w,$h-2); 
	
	  	$images[] = getName($w-2,$h-1);
	  	$images[] = getName($w-1,$h-1);
	  	$images[] = getName($w,$h-1); 
			
		$images[] = getName($w-2,$h);
	  	$images[] = getName($w-1,$h);
	  	$images[] = getName($w,$h); 
	  }
  	break;
  	
  case "ne":
  	if(checkCentral($w+1,$h-1)) {
	  	$images[] = getName($w,$h-2);
	  	$images[] = getName($w+1,$h-2);
	  	$images[] = getName($w+2,$h-2); 
	
	  	$images[] = getName($w,$h-1);
	  	$images[] = getName($w+1,$h-1);
	  	$images[] = getName($w+2,$h-1); 
			
		$images[] = getName($w,$h);
	  	$images[] = getName($w+1,$h);
	  	$images[] = getName($w+2,$h); 
	  }
  	break;
  	
  case "se":
  	if(checkCentral($w+1,$h+1)) {
	  	$images[] = getName($w,$h);
	  	$images[] = getName($w+1,$h);
	  	$images[] = getName($w+2,$h); 
	
	  	$images[] = getName($w,$h+1);
	  	$images[] = getName($w+1,$h+1);
	  	$images[] = getName($w+2,$h+1); 
			
		 	$images[] = getName($w,$h+2);
	  	$images[] = getName($w+1,$h+2);
	  	$images[] = getName($w+2,$h+2); 
	  }
  	break;
  	
  case "sw":
  	if(checkCentral($w-1,$h+1)) {
	  	$images[] = getName($w-2,$h);
	  	$images[] = getName($w-1,$h);
	  	$images[] = getName($w,$h); 
	
	  	$images[] = getName($w-2,$h+1);
	  	$images[] = getName($w-1,$h+1);
	  	$images[] = getName($w,$h+1); 
			
		$images[] = getName($w-2,$h+2);
	  	$images[] = getName($w-1,$h+2);
	  	$images[] = getName($w,$h+2); 
	  }
  	break;
  
  case "default":
  	for($x=0;$x<3;$x++) for($y=0;$y<3;$y++) $images[] = sprintf($filename,$x,$y);;
  	break;
}

$json = new json;
echo $json->encode($images);



?>