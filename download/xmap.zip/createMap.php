<?php

if(!is_dir("map_images")) mkdir("map_images");

$img = imagecreatefromjpeg("skymt_payne_big.jpg");
list($width, $height) = getimagesize("skymt_payne_big.jpg");

for($x=0; $x<$width; $x+=100) {
  for($y=0; $y<$height; $y+=100) {
		$new = imagecreate(100,100);
		imagecopy($new, $img, 0, 0, $x, $y, 100, 100 );	
		imagejpeg($new, "map_images/".($x/100)."_".($y/100).".jpg",100);
	}  
}

?>