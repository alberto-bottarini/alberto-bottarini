<?php

session_start();
if(!isset($_SESSION['xcalendar_user'])) exit();
$userId = $_SESSION['xcalendar_user'];
include("dbconf.php");
include("database.class.php");

$db = new database();

$title = mysql_real_escape_string($_POST['title']);
$text = isset($_POST['text']) ? mysql_real_escape_string($_POST['text']) : "";
$length = isset($_POST['length']) && strlen($_POST['length'])>0 ? $_POST['length'] : 1;
$date = $_POST['date'];
$type = $_POST['type'];

$day = substr($date,0,2);
$month = substr($date,3,5);
$year = substr($date,6,8);
$hour = substr($date,9,11);
$date = mktime($hour, 0, 0, $month, $day, $year);

$query = "INSERT INTO events(user,title,text,t,length,type) VALUES($userId,'$title','$text',FROM_UNIXTIME($date),$length,$type)";
echo $query;
$db->doQuery($query);
$db->close();
?>
