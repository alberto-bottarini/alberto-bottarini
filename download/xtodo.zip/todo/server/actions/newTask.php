<?php
if(!isset($_POST['name']) || strlen(trim($_POST['name'])) == 0 ) {
	$error = "No name defined";	
} elseif(!isset($_POST['note']) || strlen(trim($_POST['note'])) == 0 ) {
	$error = "No note defined";	
} elseif(!isset($_POST['user']) || strlen(trim($_POST['user'])) == 0 ) {
	$error = "No user defined";	
} elseif(!isset($_POST['priority']) || strlen(trim($_POST['priority'])) == 0 ) {
	$error = "No priority defined";			
} elseif(!isset($_POST['project_id']) || strlen(trim($_POST['project_id'])) == 0 ) {
	$error = "No project_id defined";			
} elseif($_POST['priority'] != 1 && $_POST['priority'] != 0) {
	$error = "Wrong priority code";
} else {
	$query = "SELECT * FROM projects WHERE id = '".mysql_real_escape_string($_POST['project_id'])."'";
	$result = mysql_query($query) or die(mysql_error());
	$count = mysql_num_rows($result);
	if($count == 0) $error = "No project with id ".$_POST['id'];
	elseif($count > 1) $error = "More than project task with id ".$_POST['id'];
	else {
		$query = "INSERT INTO tasks(project_id, name, note, user, priority, startdate) VALUES('".
				 $_POST['project_id']."','". 	
				 mysql_real_escape_string(htmlentities($_POST['name']))."','".
				 mysql_real_escape_string(htmlentities($_POST['note']))."','".
				 mysql_real_escape_string(htmlentities($_POST['user']))."','".
				 $_POST['priority']."',NOW())";
		mysql_query($query)  or die(mysql_error());		
		$last_id = mysql_insert_id();		  
		$query = "SELECT * FROM tasks WHERE id = '".$last_id."'";
		$result = mysql_query($query) or die(mysql_error());
		$task = mysql_fetch_assoc($result);
	}
}
?>

<?php if(!isset($error)) : ?>
	<task>
		<?php foreach($task as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>	
	</task>
<?php endif; ?>
