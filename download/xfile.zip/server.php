<?php
include("ajax/filemanager.lib.php");
include("ajax/json.php");
class response {
	
	var $path;
	var $dir;
	var $file;

	function response($path) {
		$this->path = $path;
		$fm = new filemanager($path);
		$this->dir = $fm->getDir();
		$this->file = $fm->getFile();
	}
}
$_POST['path'] = $_POST['path'];
$response = new response($_POST['path']);
$json = new json;
$encoded = $json->encode($response);
echo $encoded;
?>