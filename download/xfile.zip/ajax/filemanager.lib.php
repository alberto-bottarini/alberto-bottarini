<?php

class filemanager {

	var $dir;

	function filemanager($path) {
		if(!is_dir($path)) die("Cartella errata!!");
		$this->dir = $path;
	}

  function getDir($path = true) {
  	$res = opendir($this->dir);
  	$ret = array();
  	while(($file = readdir($res)) !== false ) {
  		if($file!="." && $file !=".." && is_dir($this->dir."/".$file)) {
  			 $ret[] = $path ? $this->dir."/".$file : $file;
  		}
  	}
		closedir($res);
  	return $ret;
  }

  function getFile($extension = array(),$path = true) {
  	$res = opendir($this->dir);
  	$ret = array();
  	$check = count($extension)!=0;
  	while(($file = readdir($res)) !== false ) {
  		if($file!="." && $file !=".." && !is_dir($this->dir."/".$file)) {
  			$ext = substr($file,-3);
	 			if(!$check || in_array(strtolower($ext),$extension)) {
  			 $ret[] = $path ? $this->dir."/".$file : $file;
  			}
  		}
  	}
		closedir($res);
  	return $ret;
  }
}
?>

