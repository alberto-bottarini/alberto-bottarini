var currentWeek = 0;
var currentEventsElements = new Array();
var currentEventsObjects = new Array();

/*NAVIGATE FUNCTION */
function getThisWeekEvents() {
	getEventByWeek();
}

function getEventByWeek() {
	param="currentWeek="+currentWeek;
	new net.ContentLoader("php/getAllEvents.php", callback, param);
}

function callback(txt) {
	removeEvents();
	var result = eval('(' + txt + ')');
	var days = result.days;
	for(i=0; i < days.length; i++) document.getElementById("day"+(i+1)).innerHTML = days[i];
	//currentDate = days[0].replace("/","").replace("/","");
	var events = result.events;
	for(e in events) {
		//div dell'evento
		var div = document.createElement("DIV");
		div.className = "event";
		div.id = events[e].id;
		if(events[e].type == 1) div.className+= " working";
		else if(events[e].type == 2) div.className+= " family";
		else if(events[e].type == 3) div.className+= " friends";
		else if(events[e].type == 4) div.className+= " other";
		div.style.height = (events[e].length * 50)+"px";
		div.style.top = (54+ 50 * (events[e].start-8))+"px";
		div.style.left = (events[e].weekDay * 102)+"px";
		var title = document.createElement("DIV");
		title.className = "title";
		title.innerHTML = events[e].title;
		div.appendChild(title);
		var text = document.createElement("DIV");
		text.className = "text";
		text.innerHTML = events[e].text
		div.appendChild(text);
		var buttons = document.createElement("DIV");
		buttons.className = "buttons";
		var updImage = document.createElement("IMG");
		updImage.src="img/upd.png";
		updImage.onclick = getEventDetails;
		updImage.alt = "updateEvent";
		buttons.appendChild(updImage);
		var remImage = document.createElement("IMG");
		remImage.src="img/rem.png";
		remImage.onclick = removeEvent;
		remImage.alr = "removeEvent";
		buttons.appendChild(remImage);
		div.appendChild(buttons);
		document.body.appendChild(div);
		currentEventsElements.push(div);
		currentEventsObjects.push(events[e]);
	}		
}

function getNextWeekEvents() {
	currentWeek++;
	getEventByWeek();
}

function getPrevWeekEvents() {
	currentWeek--;
	getEventByWeek();
}

function removeEvents() {
	while(currentEventsElements.length>0) document.body.removeChild(currentEventsElements.pop());
	currentEventsObjects = new Array();
}

/* NEW EVENT */
function addEvent(title, description, time) {
	document.getElementById("length").readOnly = false;
  var title = document.getElementById("title").value;
	var text = document.getElementById("text").value;
	var length = document.getElementById("length").value;	
	var date = document.getElementById("date").innerHTML;
	var type = document.getElementById("type").value;
	var param = "title="+title;	
	param+="&text="+text;
	param+="&date="+date;
	param+="&length="+length;
	param+="&type="+type;
	new net.ContentLoader("php/addNewEvent.php", getEventByWeek, param);	
	closeWindow();
}

/* UPDATE EVENT */
function getEventDetails() {
	var eventId = getEventIdByImage(this);
	for(e in currentEventsObjects) {
    if(currentEventsObjects[e].id == eventId) {
      var result = currentEventsObjects[e];
      break;
    }
  }
  if(result) {
  	document.getElementById("title").value = result.title;
  	document.getElementById("text").value = result.text;
  	document.getElementById("length").value = result.length;
  	document.getElementById("type").value = result.type;
  	document.getElementById("id").value = result.id;
  	var hour = result.hour;
  	var week = result.weekDay;
  	openWindow(hour, week, updateEvent);
  }
}

function updateEvent() {
	var title = document.getElementById("title").value;
	var text = document.getElementById("text").value;
	var type = document.getElementById("type").value;
	var id = document.getElementById("id").value;
	var param = "title="+title;	
	param+="&text="+text;
	param+="&type="+type;
	param+="&id="+id;	
	new net.ContentLoader("php/updateEvent.php",getThisWeekEvents, param);
	closeWindow();
}

/* REMOVE EVENT */
function removeEvent() {
	var eventId = getEventIdByImage(this);
	param = "eventId="+eventId;
	new net.ContentLoader("php/removeEvent.php",getThisWeekEvents, param);
}

function getEventIdByImage(image) {
	return image.parentNode.parentNode.id;
}

/* WINDOW */
function openWindow(hour, weekDay, callback) {
	if(hour<10) hour = "0"+hour;
	document.getElementById("date").innerHTML = document.getElementById("day"+weekDay).innerHTML+" "+hour+":00";
	document.getElementById("window").style.display="block";
	document.getElementById("formSubmit").onclick = function() {
		validateForm(callback);	
	}
	if(callback == updateEvent) document.getElementById("length").readOnly = true;
	else document.getElementById("length").readOnly = false;
}

function closeWindow() {
	document.getElementById('window').style.display='none'
	document.getElementById("title").value = "";
	document.getElementById("text").value ="";
	document.getElementById("length").value = 1;
	document.getElementById("type").value = 1;
	document.getElementById("id").value ="";
}

function validateForm(callback) {
	var title = document.getElementById("title").value;
	var length = document.getElementById("length").value;
	var date = document.getElementById("date").innerHTML;
	var hour = date.substring(date.indexOf(" ")+1,date.indexOf(" ")+3);
	if(hour.substring(0,1)=="0") hour = hour.substring(1,2);
	if(title.length==0) {
		alert("Compila il campo titolo!");
		return;
	}
	if(isNaN(length) || parseInt(hour)+parseInt(length) > 21) {
		alert("Campo durata errato!");
		return;
	}
	
	if(!validateDate(date, length)) {
		alert("Non puoi sovrapporre eventi!");
		return;
  }
  
	callback.call();	
}

function validateDate(date, length) {
  if(sameDayEvents) alert("c�");
  date = parseDate(date);
  var sameDayEvents = getSameDayEvents(date);
  if(sameDayEvents.length == 0) return true;
  var currentStart = parseInt(date['time'].substring(0, date['time'].indexOf(":")),10);
  var currentEnd = parseInt(currentStart, 10) + parseInt(length, 10);
  error = false;
  for(e in sameDayEvents) {
    var eventDate = parseDate(currentEventsObjects[e].controlDate);
    var startEvent = parseInt(eventDate['time'].substring(0, eventDate['time'].indexOf(":")),10);
    var endEvent = parseInt(startEvent, 10) + parseInt(currentEventsObjects[e].length, 10);
    //alert(startEvent +" - "+endEvent);
    //alert(currentStart +" - "+currentEnd);        
    if(currentStart < startEvent && currentEnd > startEvent) {
      error=true;
      break;
    }
  }
  return !error;
}

function getSameDayEvents(date) {
  var sameDayEvents = new Array();
  for(e in currentEventsObjects) {
    var eventDate = parseDate(currentEventsObjects[e].controlDate);
    if(eventDate['date'] == date['date']) sameDayEvents.push(currentEventsObjects[e].controlDate);
  }
  return sameDayEvents;
}

/* GLOBAL */

function parseDate(date) {
  var parse = new Array();
  parse['time'] = date.substring(date.indexOf(" ")+1);
  parse['date'] = date.substring(0, date.indexOf(" "));
  return parse;
}

window.onload = function() {
	getThisWeekEvents();
}
