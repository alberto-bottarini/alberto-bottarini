<?php
$query = "SELECT * FROM projects ORDER BY startdate";
$result = mysql_query($query, $db) or die(mysql_error());
$projects = array();
while($row = mysql_fetch_assoc($result)) $projects[] = $row;
?>

<projects>
	<?php foreach($projects as $p) : ?>
	<project>
		<?php foreach($p as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>
	</project>
	<?php endforeach; ?>
</projects>

