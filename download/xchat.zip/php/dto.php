<?php

class messaggio {
	var $utente;
	var $messaggio;
	var $data;

	function messaggio($u,$m,$d,$t) {
		$this->utente = stripslashes($u);
		$this->messaggio = stripslashes($m);
		$this->data = date("G:i:s",$d);
		$this->type = $t;
	}
}

class response {
	var $sessionId;
	var $lastId;
	var $messaggi = array();
	var $utenti = array();

	function setSessionId($id) {
		$this->sessionId = $id;
	}

	function setAllUtenti() {
  	global $db;
    $query = "SELECT nick FROM xchat_users";
    $r = $r = $db->doQuery($query);
    foreach($r as $utente) $this->utenti[] = stripslashes($utente['nick']);
	}

	function setLastId() {
  	global $db;
    $query = "SELECT MAX(id) AS last FROM xchat_mex";
    $r = $db->doQuery($query);
    $this->lastId = $r[0]['last'];
	}

	function setAllMessaggi($lastMex) {
		global $db;
    $query = "SELECT nick, mex, UNIX_TIMESTAMP(t) AS tt, type FROM xchat_mex WHERE id > '$lastMex' ORDER BY id";
    $r = $db->doQuery($query);
    foreach($r as $m) $this->messaggi[] = new messaggio($m['nick'], $m['mex'], $m['tt'], $m['type']);
	}
}

?>