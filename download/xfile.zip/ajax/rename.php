<?php
rename("../".$_POST['old'],"../".$_POST['new']);
?>