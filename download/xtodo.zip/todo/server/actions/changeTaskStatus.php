<?php
if(!isset($_POST['id'])) {
	$error = "No task defined";
} else if(!isset($_POST['status'])) {
	$error = "No status defined";
} else {
	$query = "SELECT * FROM tasks WHERE id = '".mysql_real_escape_string($_POST['id'])."'";
	$result = mysql_query($query) or die(mysql_error());
	$count = mysql_num_rows($result);
	if($count == 0) $error = "No task with id ".$_POST['id'];
	elseif($count > 1) $error = "More than one task with id ".$_POST['id'];
	elseif($status != 1 && $status !=0) $error = "Wrong status code ".$_POST['status'];
	else {
		$task = mysql_fetch_assoc($result);
		if($_POST['status'] == 1) $enddate = "NOW()";
		else $enddate = "NULL";
		$query = "UPDATE tasks SET enddate = ".$enddate." WHERE id = '".$task['id']."'";
		mysql_query($query) or die(mysql_error());
		$query = "SELECT * FROM tasks WHERE id = '".mysql_real_escape_string($_POST['id'])."'";
		$result = mysql_query($query) or die(mysql_error());
		$task = mysql_fetch_assoc($result);
	}
}
?>

<?php if(!isset($error)) : ?>
	<task>
		<?php foreach($task as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>	
	</task>
<?php endif; ?>
