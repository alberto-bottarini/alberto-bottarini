<?php
$query = "SELECT * FROM tasks ORDER BY startdate";
$result = mysql_query($query, $db) or die(mysql_error());
$projects = array();
while($row = mysql_fetch_assoc($result)) $projects[] = $row;
?>

<tasks>
	<?php foreach($projects as $p) : ?>
	<task>
		<?php foreach($p as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>
	</task>
	<?php endforeach; ?>
</tasks>
