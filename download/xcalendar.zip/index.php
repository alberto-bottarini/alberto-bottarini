<?php
session_start();
if(!isset($_SESSION['xcalendar_user'])) {
	header("Location:login.php");
	exit();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
   "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>

<head>
<link rel="stylesheet" href="style.css" type="text/css"/>
<title>XCalendar - albertobottarini.com</title>
<script type="text/javascript" src="js/net.js"></script>
<script type="text/javascript" src="js/calendar.js"></script>
</head>

<body>

<div id="head">

</div>
<div id="calendar">
	<table border="0">

		<tr>
			<td>	
			<h1>XCalendar</h1>
			<a href="logout.php">Logout</a><br/>
			<a href="#" onclick="getPrevWeekEvents(); return false">&lt;&lt; Prev</a>
			<a href="#" onclick="getNextWeekEvents(); return false">Next &gt;&gt;</a>
			</td>
			<th>Lunedi<br/><span id="day1"></span></th>
			<th>Martedi<br/><span id="day2"></span></th>
			<th>Mercoledi<br/><span id="day3"></span></th>
			<th>Giovedi<br/><span id="day4"></span></th>
			<th>Venerdi<br/><span id="day5"></span></th>
			<th>Sabato<br/><span id="day6"></span></th>
			<th>Domenica<br/><span id="day7"></span></th>
		</tr>

		<tr>
			<td class="time">08:00</td>
			<td class="class1"><a href="#" onclick="openWindow(8,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(8,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(8,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(8,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(8,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(8,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(8,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">09:00</td>
			<td class="class2"><a href="#" onclick="openWindow(9,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(9,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(9,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(9,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(9,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(9,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(9,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">10:00</td>
			<td class="class1"><a href="#" onclick="openWindow(10,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(10,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(10,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(10,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(10,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(10,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(10,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">11:00</td>
			<td class="class2"><a href="#" onclick="openWindow(11,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(11,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(11,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(11,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(11,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(11,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(11,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">12:00</td>
			<td class="class1"><a href="#" onclick="openWindow(12,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(12,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(12,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(12,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(12,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(12,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(12,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">13:00</td>
			<td class="class2"><a href="#" onclick="openWindow(13,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(13,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(13,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(13,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(13,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(13,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(13,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">14:00</td>
			<td class="class1"><a href="#" onclick="openWindow(14,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(14,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(14,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(14,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(14,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(14,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(14,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">15:00</td>
			<td class="class2"><a href="#" onclick="openWindow(15,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(15,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(15,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(15,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(15,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(15,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(15,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">16:00</td>
			<td class="class1"><a href="#" onclick="openWindow(16,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(16,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(16,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(16,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(16,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(16,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(16,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">17:00</td>
			<td class="class2"><a href="#" onclick="openWindow(17,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(17,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(17,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(17,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(17,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(17,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(17,7,addEvent)">Add event</a></td>
		</tr>
		
		<tr>
			<td class="time">18:00</td>
			<td class="class1"><a href="#" onclick="openWindow(18,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(18,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(18,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(18,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(18,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(18,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(18,7,addEvent)">Add event</a></td>
		</tr>

		<tr>
			<td class="time">19:00</td>
			<td class="class2"><a href="#" onclick="openWindow(19,1,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(19,2,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(19,3,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(19,4,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(19,5,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(19,6,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(19,7,addEvent)">Add event</a></td>
		</tr>
		
		<tr>
			<td class="time">20:00</td>
			<td class="class1"><a href="#" onclick="openWindow(20,1,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(20,2,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(20,3,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(20,4,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(20,5,addEvent)">Add event</a></td>
			<td class="class2"><a href="#" onclick="openWindow(20,6,addEvent)">Add event</a></td>
			<td class="class1"><a href="#" onclick="openWindow(20,7,addEvent)">Add event</a></td>
		</tr>


	</table>

</div>

	<div id="window">
		<div class="title">Dettagli evento</div>
		<div class="container">
		Data:<br/>
		<b id="date"></b><br/><br/>
		Titolo evento:<br/>
		<input type="text" id="title"/><br/><br/>
		Descrizione:<br/>
		<textarea id="text"></textarea><br/><br/>
		Tipologia:<br/>
		<select id="type">
		<option value="1">Working</option>
		<option value="2">Family</option>
		<option value="3">Friends</option>
		<option value="4">Other</option>
		</select>
		<br/><br/>
		Durata: <i>(in ore)</i><br/>
		<input type="text" id="length" value="1"/><br/><br/>
		<input type="hidden" id="id"/>
		<input type="submit" id="formSubmit" class="button"/>
		<br/><br/>
		<input type="submit" class="button" value="Chiudi" onclick="closeWindow()"/>
		</div>
	</div>



</body>



</html>