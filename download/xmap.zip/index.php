
<html>
<head>
<title>albertobottarini.com - XMap</title>
<style type="text/css">

#map {
  width:300px;
  height:300px;
  padding:0px;
}

#map ul {
  margin:0px;
  padding: 0px;
}

#map ul li {
  display:block;
  float:left;
  margin:0px;
  list-style-type:none;
}

#map img {
  border:0px;
  padding:0px;
  margin:0px;
}

img#thumb {
  float:right;
}
table {
  float:left;
}
table tr td {
  width: 50px;
  text-align:center;
}
</style>
</head>

<body>

<div id="map">
	<ul id="mapUl">
	</ul>
</div>



<table>
	<tr>
		<td><a href="#" onclick="getImages('nw')">NW</a></td>
		<td><a href="#" onclick="getImages('n')">N</a></td>
		<td><a href="#" onclick="getImages('ne')">NE</a></td>		
	</tr>
	<tr>
		<td><a href="#" onclick="getImages('w')">W</a></td>
		<td>&nbsp;</td>
		<td><a href="#" onclick="getImages('e')">E</a></td>		
	</tr>
	<tr>
		<td><a href="#" onclick="getImages('sw')">SW</a></td>
		<td><a href="#" onclick="getImages('s')">S</a></td>
		<td><a href="#" onclick="getImages('se')">SE</a></td>		
	</tr>
</table>

<img id="thumb" src="skymt_payne_small.jpg" alt="image"/>

<script type="text/javascript" src="lib/net.js"></script>
<script type="text/javascript">
var images = new Array();
var mapUl = document.getElementById("mapUl");

function getImages(direction) {
  if(images[4]) {
    param = "current="+images[4].src+"&direction="+direction;
		new net.ContentLoader("server.php", getImagesCallback, param);
	} else {
	  for(i=0;i<9;i++) {
	    li = document.createElement("LI");	    
		  images[i] = document.createElement("IMG");
		  li.appendChild(images[i])
		  mapUl.appendChild(images[i]);
		  
		}	  
		new net.ContentLoader("server.php", getImagesCallback);
	}	
}

function getImagesCallback(txt) {
  new_images = eval('(' + txt + ')');
  if(images.length != new_images.length) {
	  alert("ERRORE!!!");
	  return;
	}
  for(i=0;i<new_images.length;i++) {
	  images[i].src = new_images[i];
	}
}
window.onload = function() {
  getImages();
}
</script>

</body>
</html>