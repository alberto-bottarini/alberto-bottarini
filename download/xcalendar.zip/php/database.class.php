<?php

class database {

	var $connection;

	function database() {
		$this->connection = mysql_connect(DBHOST, DBUSER, DBPASS)
			or die("Connessione non riuscita: " . mysql_error());
		mysql_select_db(DBNAME, $this->connection);
	}

	function doQuery($q) {
		$query = mysql_query($q)
			or die("Errore nella query: " . mysql_error());
		if(is_numeric(strpos($q, "SELECT"))) {
			$array = array();
			while($row = mysql_fetch_assoc($query)) $array[] = $row;
			return $array;
		} else return false;
	}

	function close() {
		mysql_close($this->connection);
	}

}

?>