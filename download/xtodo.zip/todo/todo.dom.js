todo.dom = {
	init : function() {
		var elems = new Array();
		var li = $("<li class='general selected'>Homepage</li>");
		li.click(todo.controller.getHomepage);
		var ul = $("<ul id='tabs'></ul>");
		ul.append(li);
		var cont = $("div#container")
		cont.append( ul );
		cont.append( $("<br style='clear:both'>") );
		cont.append( $("<div id='content'></div>") );
		$("body").append("<img src='opt/load.gif' id='loadImg'/>" );
	},	
	homepage : function(countProjects, countTasks) {
		var h1 = $("<h1>xToDo - Gestire progetti con AJAX</h1>");
		var div = $("<div>Attualmente ci sono <b>"+countProjects+"</b> progetti e <b>"+countTasks+"</b> task inseriti nell'applicazione.</div>");
		var box = $("<div class='box'></div>");
		var newProjectLink = $("<a href='#'>New project</a>");
		newProjectLink.click(todo.dom.projectForm);
		box.append(newProjectLink);
		var cont = $('div#content');
		cont.empty();
		cont.append(h1);
		cont.append(div);
		cont.append(box);
	},	
	projectDetails : function(project,tasks) {
		var h1 = $("<h1>Dettaglio progetto "+project.name+"</h1>");
		var box = $("<div class='right box'>Progetto creato il "+project.startdate+"</div>");
		var note = $("<em>"+project.note+"</em>");
		var brs = $("<br class='clear'/><br class='clear'/>");
		var box2 = $("<div class='box'></div>");
		var removeProjectLink = $("<a class='right' href='#'>Remove project</a>");
		removeProjectLink.bind( "click", project.id, todo.controller.removeProject );
		box2.append(removeProjectLink);
		var newTaskLink = $("<a href='#'>New task</a>");
		newTaskLink.bind( "click", project.id, todo.dom.taskForm );
		box2.append(newTaskLink);		
		
		var table = $("<table></table>");
		var th = $("<tr><th></th><th>Task</th><th>User</th><th>Data creazione</th><th>Data chiusura</th></tr>");
		table.append(th);
		for(var t = 0; t<tasks.length; t++) {
			var status = tasks[t].enddate ? "open" : "close";
			var priority = tasks[t].priority == 1;
			var tr = $("<tr class='"+status+"'></tr>");		
			var tds = new Array();	
			if(priority) tds.push($("<td align='center' width='2%'><img src='opt/priority.gif' alt='priority'/></td>"));
			else tds.push($("<td width='2%'></td>"));
			tds.push($("<td>"+tasks[t].name+"<br/><em>"+tasks[t].note+"</em></td>"));
			tds.push($("<td width='10%'>"+tasks[t].user+"</td>"));
			tds.push($("<td width='10%'>"+tasks[t].startdate+"</td>"));
			if(tasks[t].enddate) {
				tds.push($("<td width='10%'>"+tasks[t].enddate+"</td>"));
				tds.push($("<td width='2%'></td>"));
				var changeStatusImg = $("<img src='opt/opentask.png' alt='opentask' class='link'/>");
				changeStatusImg.bind("click", {status:0, id:tasks[t].id}, todo.controller.changeTaskStatus );
			} else {
				tds.push($("<td width='10%'></td>"));
				tds.push($("<td width='2%'></td>"));
				var changeStatusImg = $("<img src='opt/closetask.png' alt='closetask' class='link'/>");
				changeStatusImg.bind("click", {status:1, id:tasks[t].id}, todo.controller.changeTaskStatus );
			}		
			tds[5].append(changeStatusImg);
			tds.push($("<td width='2%'></td>"));
			var removeTaskImg = $("<img src='opt/removetask.png' alt='removetask' class='link'/>");
			removeTaskImg.bind("click", tasks[t].id, todo.controller.removeTask);
			tds[6].append(removeTaskImg);
			for(i in tds) tr.append(tds[i]);
			table.append(tr);
		}		
		table.css({display:"none"});
		var cont = $('div#content');
		cont.empty();
		cont.append(h1);
		cont.append(box);
		cont.append(note);
		cont.append(brs);
		cont.append(box2);
		cont.append(table);
		table.slideDown("slow");
	},
	taskForm : function(event){
		var div = $("<div id='taskForm'></div>");
		div.append($("<h2>New Task</h2>"));
		var form = $("<form action='#' method='post'></form>");
		form.bind("submit", event.data, todo.controller.taskFormSubmit );
		var label1 = $("<label for='task_name'>Name</label>");
		var input1 = $("<input type='text' name='task_name'/>");
		var brs = $("<br/><br/>");
		var label2 = $("<label for='task_user'>User</label>");
		var input2 = $("<input type='text' name='task_user'/>");		
		var label3 = $("<label for='task_note'>Note</label>");
		var input3 = $("<textarea name='task_note'></textarea>");	
		var label4 = $("<label for='task_priority'>Priority</label>");
		var input4 = $("<select name='task_priority'><option value='0'>Normal</option><option value='1'>High</option></select>");
		var submit = $("<input type='submit' class='button' value='Save!'/>");
		var closeButton = $("<input type='button' class='button' value='Close!'/>");
		closeButton.click( todo.dom.taskFormClose );
		form.append(label1);
		form.append(input1);
		form.append(brs);
    form.append(label2);
    form.append(input2);
    form.append(brs);
    form.append(label3);
    form.append(input3);
    form.append(brs);
    form.append(label4);
    form.append(input4);
    form.append(brs);
		form.append(submit);
		form.append(closeButton);
		div.append(form);
		$("div#content").append(div);		
	},
	taskFormClose : function() {
		 $("div#taskForm").remove();
	},
	projectForm : function(){
		var div = $("<div id='projectForm'></div>");
		div.append($("<h2>New Project</h2>"));
		var form = $("<form action='#' method='post'></form>");
		form.submit(todo.controller.projectFormSubmit);
		var label1 = $("<label for='project_name'>Name</label>");
		var input1 = $("<input type='text' name='project_name'/>");
		var brs = $("<br/><br/>");
		var label2 = $("<label for='project_note'>Note</label>");
		var input2 = $("<textarea name='project_note'></textarea>");
		var submit = $("<input type='submit' class='button' value='Save!'/>");
		var closeButton = $("<input type='button' class='button' value='Close!'/>");
		closeButton.click( todo.dom.projectFormClose );
		form.append(label1);
		form.append(input1);
		form.append(brs);
		form.append(label2);
    form.append(input2);
    form.append(brs);
		form.append(submit);
		form.append(closeButton);
		div.append(form);
		$("div#content").append(div);
	},
	projectFormClose : function() {
		 $("div#projectForm").remove();
	},
	createTab : function(project) {
		var name = project.name;
		var tab = $("<li>"+name+"</li>");
		tab.css({display:'none'});
		tab.bind( "click", project.id, todo.controller.getProjectDetails );
		$("ul#tabs").append(tab);
		tab.fadeIn();
	},
	selectTab : function(target) {
		$('ul#tabs li.selected').removeClass("selected");
		$(target).addClass("selected");		
	}
}
