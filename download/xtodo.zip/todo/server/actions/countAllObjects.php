<?php
$query = "SELECT COUNT(*) AS projects FROM projects";
$result = mysql_query($query, $db) or die(mysql_error());
$projects = array();
$counts = mysql_fetch_assoc($result);
$query = "SELECT COUNT(*) AS tasks FROM tasks";
$result = mysql_query($query, $db) or die(mysql_error());
$projects = array();
$counts = array_merge($counts,mysql_fetch_assoc($result));
?>

<counts>
	<?php foreach($counts as $key => $value) : ?>
		<<?php echo $key; ?>><?php echo $value; ?></<?php echo $key; ?>>
	<?php endforeach; ?>
</counts>

