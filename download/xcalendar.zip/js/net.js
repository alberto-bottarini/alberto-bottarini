net = new Object();
net.ContentLoader = function(url, onload, params) {
	this.onload = onload;
	this.loadXMLDoc(url, params);

}

net.ContentLoader.prototype = {
	loadXMLDoc: function(url, params) {
    try { 
			this.req = new ActiveXObject("Msxml2.XMLHTTP"); 
		}
    catch (e) {
     try  { this.req = new ActiveXObject("Microsoft.XMLHTTP"); }
      catch (e)
        {
          try { this.req = new XMLHttpRequest(); }
          catch (e)
            {
              try { this.req = window.createRequest(); }
              catch (e) { alert(e); }
            }
        }
    }
  	if(this.req) {
  		try {			
  			var loader = this;	
  			this.req.open("POST", url, true);
  			this.req.onreadystatechange = function() {
  				loader.onReadyState.call(loader);
  			}			
				if(params!=null) this.req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
 				if (params) this.req.send(params);
				else this.req.send("");
  		} catch(e) {
  			alert(e);
  		}
  	}
	},
	onReadyState: function() {
  	var req = this.req;
  	var ready = this.req.readyState;
  	data = null;		
  	if(ready == 4) {
			data = this.req.responseText;
			this.onload(data);  	
		}
  }
}