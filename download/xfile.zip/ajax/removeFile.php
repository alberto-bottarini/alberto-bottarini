<?php
$folder = $_POST['file'];
unlink("../$folder");

?>