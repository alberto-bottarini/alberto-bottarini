<?php
if(!isset($_POST['id'])) {
	$error = "No project defined";
} else {
	$query = "SELECT * FROM projects WHERE id = '".mysql_real_escape_string($_POST['id'])."'";
	$result = mysql_query($query) or die(mysql_error());
	$count = mysql_num_rows($result);
	if($count == 0) $error = "No project with id ".$_POST['id'];
	elseif($count > 1) $error = "More project one task with id ".$_POST['id'];
	else {
		$project = mysql_fetch_assoc($result);
		$query = "DELETE FROM projects WHERE id = '".$project['id']."'";
		mysql_query($query) or die(mysql_error());	
		$query = "DELETE FROM tasks WHERE project_id = '".$project['id']."'";
		mysql_query($query) or die(mysql_error());			
	}
}
?>

<?php if(!isset($error)) : ?>
	<task>
		<?php foreach($task as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>	
	</task>
<?php endif; ?>
