<?php
session_start();
if(!isset($_SESSION['xcalendar_user']) || !isset($_POST['eventId'])) exit();
$userId = $_SESSION['xcalendar_user'];
include("dbconf.php");
include("database.class.php");
$eventId = $_POST['eventId'];

$db = new database();
$query = "SELECT * FROM events WHERE id = $eventId";
$result = $db->doQuery($query);
if(count($result) == 0) exit();
$event = $result[0];
if($event['user'] != $userId) exit();

$query = "DELETE FROM events WHERE id = $eventId";
$db->doQuery($query);

?>
