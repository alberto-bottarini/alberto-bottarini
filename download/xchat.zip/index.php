<?php echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n"; ?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>albertobottarini.com - XChat</title>
<script type="text/javascript" src="net.js"></script>
<script type="text/javascript" src="xchat.js"></script>
<script type="text/javascript" src="utils.js"></script>
<style type="text/css">
body,input,button { font-size:12px; font-family:verdana }
div { border: 1px solid black }
div#mex { height: 300px; overflow:auto }
div#form span { display:block; width: 70px; float:left }
div#mex span.newUser { color:green }
div#mex span.changeNick { color:darkblue }
input { width: 300px; margin-left: 80px }
</style>
</head>
<body>
<div id="form">
<span id="nickname">Nickname:</span>
<input type="text" id="nickInput" value="nick"/>
<button id="nickButton">Login!</button>
</div>
</body>
</html>
