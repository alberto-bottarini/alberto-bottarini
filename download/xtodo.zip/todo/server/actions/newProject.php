<?php
if(!isset($_POST['name']) || strlen(trim($_POST['name'])) == 0 ) {
	$error = "No name defined";	
} elseif(!isset($_POST['note']) || strlen(trim($_POST['note'])) == 0 ) {
	$error = "No note defined";	
} else {
	$query = "INSERT INTO projects(name, note, startdate) VALUES('".
			 mysql_real_escape_string(htmlentities($_POST['name']))."','".
			 mysql_real_escape_string(htmlentities($_POST['note']))."',NOW())";
	mysql_query($query)  or die(mysql_error());		
	$last_id = mysql_insert_id();		  
	$query = "SELECT * FROM projects WHERE id = '".mysql_real_escape_string($last_id)."'";
	$result = mysql_query($query) or die(mysql_error());
	$project = mysql_fetch_assoc($result);	
}
?>

<?php if(!isset($error)) : ?>
	<project>
		<?php foreach($project as $key => $value) : ?>
			<?php if(!is_null($value)) : ?>
				<<?php echo $key; ?>><?php echo utf8_encode($value); ?></<?php echo $key; ?>>
			<?php endif; ?>
		<?php endforeach; ?>	
	</project>
<?php endif; ?>
