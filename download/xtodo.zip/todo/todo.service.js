todo.service = {
	loadMenu : function(selected) {
		$("ul#tabs li:not(.general)").remove();
		todo.ajax.getData(todo.url.getAllProjects, null, function() {
			var projects = util.getAsArray(this.projects.project);	
			for(i in projects) todo.dom.createTab(projects[i]);
			if(selected) todo.dom.selectTab(selected);
		});
	},
	getHomepage : function() {
		todo.ajax.getData(todo.url.countAllObject, null, function() {
			todo.dom.homepage(this.counts.projects, this.counts.tasks);
		});
	},
	getProjectDetails : function(id) {		
		todo.ajax.getData(todo.url.getProject, {id:id}, function() {
			var project = this.project;
			var tasks = util.getAsArray(project.task);
			todo.dom.projectDetails(project,tasks);
		});
	},
	changeTaskStatus : function(id, status) {
		todo.ajax.getData(todo.url.changeTaskStatus, {id:id, status:status}, function() {
			todo.service.getProjectDetails(this.task.project_id);
		});	
	},
	removeTask : function(id) {
		todo.ajax.getData(todo.url.removeTask, {id:id}, function() {
			todo.service.getProjectDetails(this.task.project_id);
		});	
	},
	removeProject : function(id) {
		todo.ajax.getData(todo.url.removeProject, {id:id}, function() {
			alert("Project removed!");
			todo.service.loadMenu($('ul#tabs li.general'));
			todo.service.getHomepage();
		});			
	},
	taskFormSubmit : function(project_id, name, note, user, priority) {
		todo.ajax.getData(todo.url.newTask, {project_id: project_id, name: name, note: note, user: user, priority: priority}, function() {
			alert("Task created!");
			todo.service.getProjectDetails(this.task.project_id);
		});	
	},
	projectFormSubmit : function(name, note) {
		todo.ajax.getData(todo.url.newProject, {name: name, note: note}, function() {
			alert("Project created!");
			todo.service.loadMenu($('ul li:last'));			
			todo.service.getProjectDetails(this.project.id);
		});
	}
}
