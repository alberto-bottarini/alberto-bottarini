div#content ul li {
	background: url(file.bmp) center top no-repeat;
}

<?php
if ($handle = opendir('.')) {

   while (false !== ($file = readdir($handle))) if($file!= "Thumbs.db" && $file!="." && $file!=".." && $file !="style.php") {
     $name = substr($file, 0,-4);
?>
div#content ul li.<?=$name?> {
	background: url(<?=$file?>) center top no-repeat;
}

<?php
   }

closedir($handle);
}
?> 
