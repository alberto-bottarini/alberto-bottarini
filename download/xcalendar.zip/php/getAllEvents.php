<?php
session_start();
if(!isset($_SESSION['xcalendar_user'])) exit();
include("dbconf.php");
include("database.class.php");
include("json.php");
$userId = $_SESSION['xcalendar_user'];
$diffDays = isset($_POST['currentWeek']) ? $_POST['currentWeek']*7 : 0;
$currentDate = mktime (0,0,0, date("m"), date("d")+$diffDays, date("y"));

$weekDay = date("w", $currentDate);
if($weekDay == 0) $weekDay = 6;
else $weekDay--;

$start = date("d", $currentDate)-$weekDay;
$startDay = mktime (0,0,0, date("m", $currentDate),$start , date("y", $currentDate));
$endDay = mktime (0,0,0, date("m", $currentDate),$start+7 , date("y", $currentDate));;

$days = array();
for($i=$start; $i<=$start+6; $i++) $days[] = date("d/m/y",mktime (0,0,0, date("m", $currentDate),$i , date("y", $currentDate)));

$db = new database();
$query = "SELECT *, UNIX_TIMESTAMP(t) as tt FROM events WHERE t>= FROM_UNIXTIME({$startDay}) AND t <= FROM_UNIXTIME({$endDay}) AND user = $userId";
$events = $db->doQuery($query);
$db->close();

for($i=0; $i<count($events); $i++) {
	$start = $events[$i]['tt'];
	$events[$i]['weekDay'] = date("w", $start)==0 ? 7: date("w", $start);
	$events[$i]['start'] = date("H", $start);
	$events[$i]['controlDate'] = date("d/m/y H:i", $start);
}

$result = array("days" => $days, "events" => $events);

$json = new json();
echo $json->encode($result);
?>

	
