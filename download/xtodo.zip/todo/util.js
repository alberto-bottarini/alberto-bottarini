var util = {
	isArray: function(array) {
		return !( !array || (!array.length || array.length == 0) || typeof array !== 'object' || !array.constructor || array.nodeType || array.item ); 
	},
	isUndefined: function(obj) {
		return typeof obj == 'undefined';
	},
	getAsArray: function(node) {
		if(!node) return new Array();
		if(!util.isArray(node)) return new Array(node);
		return node;
	}	
}	
