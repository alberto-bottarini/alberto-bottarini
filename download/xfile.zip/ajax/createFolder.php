<?php
$folder = $_POST['folder'];
mkdir("../$folder");

?>