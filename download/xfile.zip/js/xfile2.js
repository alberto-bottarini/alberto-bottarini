//CONSTANT
var homePage = "prova";

// GLOBAL VARS
var listfile;
var previousPages = new Array();
var nextPages = new Array();
var contextFile = true;
var contextSelected;

//ONLOAD FUNCTION
window.onload = function() {
  if(!NiftyCheck()) return;
  Rounded("div#window","#FFFFFF","blue","small");
  listfile = document.getElementById("listfile");
  request(homePage);
  document.getElementById("window").oncontextmenu = showContext;
}

//REQUEST
function request(path) {
	var param = "path="+path;
	new net.ContentLoader("server.php",updateFileCallback,param);
}

//UPDATE CONTENT FUNCTION
function updateFile(id) {
	previousPages.push(getCurrentPage());
	clearAheadPages()
	request(id);
}

function updateFileCallback(txt) {
	var response = eval('(' + txt + ')');
	clearContent();
	updateStatus(response.path);
	var dirs = response.dir;
	var files = response.file;
	newDirectories(dirs);
	newFiles(files);
	setBackButton();
	setAheadButton();
	setUpButton();
}

function clearContent() {
	var elt = document.getElementById("listfile");
	var childs = elt.childNodes;
	while (ch = elt.firstChild) elt.removeChild(ch);
}

function newDirectories(dirs) {
	for(i=0;i<dirs.length;i++) {
		var dd = dirs[i];
		var li = document.createElement("LI");
		li.className = "folder";
		li.id = formatId(dd);
		li.onclick = new Function("updateFile('"+dd+"')");
		var span = document.createElement("SPAN");
		span.innerHTML = formatPath(dd);
		li.appendChild(span);
		li.onmouseover = function() {
		  this.style.border = "1px solid #CCCCCC";
		}
		li.onmouseout = function() {
		  this.style.border = "1px solid #FFFFFF";
		}
		li.oncontextmenu = function(e) {
		  showContext(e, this.className);
		}
		listfile.appendChild(li);
	}
}

function newFiles(files) {
	for(i=0;i<files.length;i++) {
		var ff = files[i];
		var li = document.createElement("LI");
		var ext = getExtension(ff);
		li.className = ext;
		li.id = formatId(ff);
		linka = new Function("document.location='"+ff+"'");
		li.onclick = linka;
		var span = document.createElement("SPAN");
		span.innerHTML = formatPath(ff);
		li.appendChild(span);
		li.onmouseover = function() {
		  this.style.border = "1px solid #CCCCCC";
		}
		li.onmouseout = function() {
		  this.style.border = "1px solid #FFFFFF";
		}
		li.oncontextmenu = function(e) {
		  showContext(e, this.className);
		}
		listfile.appendChild(li);
	}
}

//UPDATE INTERFACE FUNCTION
function updateStatus(mex) {
		document.getElementById("statusbar").innerHTML = mex;
}

function setBackButton() {
	var d = document.getElementById("backlink");
	if(previousPages.length > 0) {
		d.className = "backLinkOn";
		d.onclick = goBack;
	}	else d.className = "backLinkOff";
}

function setAheadButton() {
	var d = document.getElementById("aheadlink");
	if(nextPages.length > 0) {
		d.className = "aheadLinkOn";
		d.onclick = goAhead;
	}	else d.className = "aheadLinkOff";
}

function setUpButton() {
	var current = getCurrentPage();
	var d = document.getElementById("uplink");
	if(current == homePage) {
		d.className = "upLinkOff";
	} else {
		d.className = "upLinkOn";
		d.onclick = goUp;
	}
}

//FORMATTING FUNCTION
function formatPath(path) {
	var path = path.substring(path.lastIndexOf("/")+1);
	if(path.length > 12) path = path.substring(0,9)+"...";
	return path;
}

function formatId(id) {
	id = id.replace("\\","");
	return id;
}

function getExtension(path) {
	return path.substring(path.lastIndexOf(".")+1);
}

//BACK-AHEAD-UP FUNCTION

function goBack() {
	nextPages.push(getCurrentPage());
	var path = previousPages.pop();
	request(path);
}

function goAhead() {
	previousPages.push(getCurrentPage());
	var path = nextPages.pop();
	request(path);
}

function goUp() {
	var current = getCurrentPage();
	current = current.substring(0,current.lastIndexOf("/"));
	previousPages.push(getCurrentPage());
	request(current);
}

function clearAheadPages() {
	nextPages = new Array();
}

//CONTEXT MENU FUNCTION

function createContext(e) {
  var arr = new Array();
  arr[0] = new Array("Create Folder", createFolder);
	createContextPanel(e, arr);
}

function createContextFile(e, type) {
  var arr = new Array();
  if(type == "folder") {
  	arr.push(new Array("Remove Folder", removeFolder));
  	arr.push(new Array("Rename Folder", renameFolder));
	} else {
	  arr.push(new Array("Remove File", removeFile));
	  arr.push(new Array("Rename File", renameFile));
	}
	createContextPanel(e, arr);
}

function createContextPanel(e, lis) {
	var div = document.createElement("DIV");
	div.oncontextmenu = function() { return false }
	div.className = "contextMenu";
	div.id = "contextMenu";
	div.style.top = e.clientY+"px";
	div.style.left = e.clientX+"px";
	var ul = document.createElement("UL");
	for(i=0; i<lis.length;i++) {
	  var li = document.createElement("LI");
	  var a = document.createElement("A");
	  a.innerHTML = lis[i][0];
	  a.href = "#"
	  a.onclick = lis[i][1];
	  li.appendChild(a);
	  ul.appendChild(li);
	}
	div.appendChild(ul);
	document.body.appendChild(div);
}

function destroyContext() {
	if(document.getElementById("contextMenu"))
		document.body.removeChild(document.getElementById("contextMenu"));
}

function showContext(e, type) {
  if(!e) {
		var e = window.event;
		var elem = e.srcElement;  
	} else var elem = e.currentTarget;
  if(type) {
    destroyContext();
    contextFile = false;
    contextSelected = elem;
	  createContextFile(e, type);	  
	} else if(contextFile) {
    destroyContext();
	  createContext(e);
	} else contextFile = true;
  	document.getElementById("window").onclick = destroyContext;
	return false; 
}

//CONTEXT MENU CONTENT FUNCTION

function createFolder() {
	destroyContext();
	var name = trim(input("Inserisci il nome della cartella",""));
	if(name) {
	  var param = "folder="+getCurrentPage()+"/"+name;
	  new net.ContentLoader("ajax/createFolder.php",refreshPage,param);
	}
}

function removeFolder() {
	destroyContext();
	var yourstate = window.confirm("Sei sicuro?? Cancellerai anche tutti i file contenuti!")
	if (yourstate) {
	  var param = "folder="+contextSelected.id;
	  new net.ContentLoader("ajax/removeFolder.php",refreshPage,param);
	}
}

function removeFile() {
	destroyContext();
	var yourstate = window.confirm("Sei sicuro??")
	if (yourstate) {
	  var param = "file="+contextSelected.id;
	  new net.ContentLoader("ajax/removeFile.php",refreshPage,param);
	}
}

function renameFolder() {
	destroyContext();
	var folderName = contextSelected.id.substring(contextSelected.id.lastIndexOf("/")+1);
	var folderPath = contextSelected.id.substring(0, contextSelected.id.lastIndexOf("/")+1);
	var name = trim(input("Inserisci il nuovo nome della cartella",folderName).replace(/[\\:\?\*\/"<>\|]+/g, "_"));
	if(name) {
	  var o = folderPath+folderName;
	  var n = folderPath+name;
	  var param = "old="+o+"&new="+n;
	  new net.ContentLoader("ajax/rename.php",refreshPage,param);
	}
}

function renameFile() {
	destroyContext();
	var fileName = contextSelected.id.substring(contextSelected.id.lastIndexOf("/")+1);
	var filePath = contextSelected.id.substring(0, contextSelected.id.lastIndexOf("/")+1);
	name = trim(input("Inserisci il nuovo nome del file", fileName).replace(/[\\:\?\*\/"<>\|]+/g, "_"));
	if(name) {
	  var o = filePath+fileName;
	  var n = filePath+name;
	  var param = "old="+o+"&new="+n;
	  new net.ContentLoader("ajax/rename.php",refreshPage,param);
	}
}

//GENERAL FUNCTION

function getCurrentPage() {
	return document.getElementById("statusbar").innerHTML;
}

function trim(str) {
  if(!str || str.length == 0) return str;
	return str.replace(/\s+$|^\s+/g,"");
}

function input(txt, d) {
	var res = window.prompt(txt,d,"");
	return res;  
}

function refreshPage(){
  request(getCurrentPage());
}
	