todo.ajax = {
	init: function() {
		$.ajaxSetup({
			dataType: "text",
			beforeSend : todo.ajax.events.onStartLoading,
			complete : todo.ajax.events.onStopLoading,
			error : todo.ajax.events.onError
		});
	},
	getData: function(url, params, handler) {
		$.post(url, params, function(data) {
			var objs = xml2json.parser(data);
			if(objs.error) alert("ERROR:\n"+objs.error);
			else handler.call(objs);
		});
	},
	events : {
		onStartLoading : function() {
			if(todo.ajax.status.concurrentConnections==0) {
				todo.ajax.status.isLoading = true;   
				$('img#loadImg').css({display:'block'});										
			}
			todo.ajax.status.concurrentConnections++;	         
			
		},
		onStopLoading : function() {
			todo.ajax.status.concurrentConnections--;	 
			if(todo.ajax.status.concurrentConnections==0) {
				todo.ajax.status.isLoading = false;   
				$('img#loadImg').css({display:'none'});										
			}
		},
		onError : function(xhr, st, er) {
			isLoading = false;  
			todo.ajax.status.concurrentConnections--;
			alert("ERROR:\nstatus: "+st+"\nerror: "+er);
		}
	},
	status : {
		concurrentConnections : 0,
		isLoading : false
	}
}
