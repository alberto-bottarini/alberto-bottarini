<?php
define("DBNAME", "");
define("DBHOST", "");
define("DBUSER", "");
define("DBPASS", "");
?>
