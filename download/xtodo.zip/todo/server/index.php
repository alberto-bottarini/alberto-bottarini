<?php

/* configurazione DB */
define("DB_HOST","****");
define("DB_USER","****");
define("DB_PASS","****");
define("DB_NAME","****");
/* fine configurazione DB */

$db = mysql_connect(DB_HOST, DB_USER, DB_PASS);
mysql_select_db(DB_NAME, $db);

$actions = array();
$actionsDir = "./actions";
$dir = opendir("./actions");
while(false !== ($file = readdir($dir))) if(is_file($actionsDir."/".$file)) $actions[] = substr($file,0,strpos($file,"."));

header("Content-type: text/xml");
echo "<"."?xml version=\"1.0\" encoding=\"utf-8\"?>";



if(isset($_GET['action'])) {
	if(in_array($_GET['action'], $actions)) include($actionsDir."/".$_GET['action'].".php");
	else $error = "Action ".$_GET['action']." does not exists";	
} else $error = "No action defined";


if(isset($error)) {
	echo "<error>$error!</error>";
}

mysql_close($db);

?>
